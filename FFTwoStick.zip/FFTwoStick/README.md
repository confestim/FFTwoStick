## FFTwoStick

> Be cool! Be toxic! FF immediately!

Best served with [instant suite](https://bakkesplugins.com/plugins/view/14), you can now finally ff in the press of ~a~ two buttons.

Just press L3(left analog) and R3(right analog) and profit!

![Controller](https://images.squarespace-cdn.com/content/v1/55760816e4b088027cd216c5/1603406539992-BX5BSEUDKO6KXUSNZGR4/PS4-Controller-diagram.jpg)


### Todos
- [ ] Dynamic ff popup (based on gamemode and score)
- [ ] Better code (it's so bad rn)
- [ ] Settings tab on bakkes
- [ ] Customizable binds